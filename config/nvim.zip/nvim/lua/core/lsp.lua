
local clang_tools_path = os.getenv "CLANG_TOOLS_PATH"
require("lspconfig").clangd.setup {
  cmd = { clang_tools_path .. "/clangd", "--background-index" },
  -- You can add other settings specific to clangd here
  on_attach = function(client, bufnr)
    -- Set omnifunc for LSP completion
    vim.bo[bufnr].omnifunc = "v:lua.vim.lsp.omnifunc"

    -- Keybinding options
    local opts = { noremap = true, silent = true }
    local keymap = vim.api.nvim_buf_set_keymap

    -- Hover Document: Shift + K
    keymap(bufnr, "n", "K", "<Cmd>lua vim.lsp.buf.hover()<CR>", opts)

    -- Format Document: Space + lf
    keymap(bufnr, "n", "<leader>lf", "<Cmd>lua vim.lsp.buf.format{ async = true }<CR>", opts)

    -- Symbols Outline: Space + lS (Note: Requires a plugin like 'simrat39/symbols-outline.nvim')
    keymap(bufnr, "n", "<leader>lS", "<Cmd>SymbolsOutline<CR>", opts)

    -- Line Diagnostics: gl, Space + ld
    keymap(bufnr, "n", "gl", "<Cmd>lua vim.diagnostic.open_float()<CR>", opts)
    keymap(bufnr, "n", "<leader>ld", "<Cmd>lua vim.diagnostic.open_float()<CR>", opts)

    -- All Diagnostics: Space + lD
    keymap(bufnr, "n", "<leader>lD", "<Cmd>lua vim.diagnostic.setloclist()<CR>", opts)

    -- Code Actions: Space + la
    keymap(bufnr, "n", "<leader>la", "<Cmd>lua vim.lsp.buf.code_action()<CR>", opts)

    -- Signature Help: Space + lh
    keymap(bufnr, "n", "<leader>lh", "<Cmd>lua vim.lsp.buf.signature_help()<CR>", opts)

    -- Rename: Space + lr
    keymap(bufnr, "n", "<leader>lr", "<Cmd>lua vim.lsp.buf.rename()<CR>", opts)

    -- Document Symbols: Space + ls
    keymap(bufnr, "n", "<leader>ls", "<Cmd>lua vim.lsp.buf.document_symbol()<CR>", opts)
  end,
}
