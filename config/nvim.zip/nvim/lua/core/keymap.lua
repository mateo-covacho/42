vim.api.nvim_set_keymap("n", "<A-Down>", ":m .+1<CR>==", { noremap = true, silent = true })
vim.api.nvim_set_keymap("n", "<A-Up>", ":m .-2<CR>==", { noremap = true, silent = true })

-- Move selected lines down
vim.api.nvim_set_keymap("v", "<A-Down>", ":m '>+1<CR>gv=gv", { noremap = true, silent = true })

-- Move selected lines up
vim.api.nvim_set_keymap("v", "<A-Up>", ":m '<-2<CR>gv=gv", { noremap = true, silent = true })

-- vim.api.nvim_set_keymap("n", "?", "<cmd>Telescope marks<cr>", { noremap = true, silent = true })
-- vim.api.nvim_set_keymap("n", "'", "<cmd>Telescope marks<cr>", { noremap = true, silent = true })

vim.api.nvim_set_keymap("n", "<M-c>", ":ChatGPT", { noremap = true, silent = true })

-- -- Unmap Tab for Copilot
-- vim.api.nvim_set_keymap("i", "<Tab>", "v:lua.check_backspace() ? '<Tab>' : copilot#Accept()", { expr = true, silent = true })
-- Map Ctrl+Right to accept Copilot suggestion

vim.api.nvim_set_keymap("i", "<C-Right>", "copilot#Accept('<CR>')", { expr = true, silent = true })


-- vim.api.nvim_set_keymap('n', '<lead-P>', ':Legendary keymaps<CR>', { noremap = true, silent = true })
-- vim.api.nvim_set_keymap('n', '<Space>P', ':Telescope keymaps<CR>', { noremap = true, silent = true })


vim.api.nvim_set_keymap('n', '<Space>P', ':Legendary commands<CR>', { noremap = true, silent = true })
vim.api.nvim_set_keymap('n', '<Space>K', ':Legendary keymaps<CR>', { noremap = true, silent = true })
